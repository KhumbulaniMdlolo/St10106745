﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part1
{
    class Ingredients
    {

        List<string> ingredients = new List<string>();
        List<double> quantities = new List<double>();
        List<string> units = new List<string>();

        public void getUserInput()
        {

            for (int i = 0; i < RecipeApp.numOfIngredients; i++)
            {
                Console.Write("Ingredient Name: ");
                string ingredient = Console.ReadLine();
                ingredients.Add(ingredient);

                Console.Write("Quantity: ");
                double quantity = Convert.ToDouble(Console.ReadLine());
                quantities.Add(quantity);

                Console.Write(" Measurement Unit : ");
                string unit = Console.ReadLine();
                units.Add(unit);
            }
        }
    }
        public void getUserOutput()
        {
            Console.WriteLine("------------------Recipe-------------------");

            for (int i = 0; i < ingredients.Count; i++)
            {
                Console.WriteLine("------------------Recipe"+(1+i)+"-------------------");
                Console.WriteLine("Quantity: " + quantities[i] + " \nUnits Of Measurement: " + units[i] + " \nIngedients Name: " + ingredients[i]);
                Console.WriteLine("-------------------------------------");
            }
        }
    }
}
