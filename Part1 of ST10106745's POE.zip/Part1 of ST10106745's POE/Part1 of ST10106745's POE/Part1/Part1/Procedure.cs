﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part1
{
    internal class Procedure
    {
        List<string> procedure = new List<string>();
        public void getProcedure()
        {
            for (int i = 0; i < RecipeApp.numOfProcedure; i++)
            {
                Console.Write("Procedure " + (i + 1) + ": ");
                string step = Console.ReadLine();
                procedure.Add(procedure);
            }
        }
        public void getUserOutput()
        {
            Console.WriteLine("**************Procedure*************");
            for (int i = 0; i < RecipeApp.numOfSteps; i++)
            {
                Console.WriteLine("Procedures"+(i + 1) + ": " + steps[i]);
            }
        }
    }
}
