﻿using System;
using System.Collections.Generic;
using static System.Formats.Asn1.AsnWriter;
using System.Diagnostics.Metrics;
using System.Numerics;
using System.Runtime.ConstrainedExecution;
using System.Text.RegularExpressions;
using Part1;
class RecipeApp
{
    public static int numOfIngredients;
    public static int numOfSteps;
    static void Main(string[] args)
    {
        List<string> ingredients = new List<string>();
        List<double> quantities = new List<double>();
        List<string> units = new List<string>();
        List<string> steps = new List<string>()
        Console.WriteLine("*****************\nWelcome to XXP Recipe\n******************* ");
        Console.WriteLine("*****************\nDetails of new recipe\n******************* ");
        Console.Write("No of ingredients: ");
        numOfIngredients = Convert.ToInt32(Console.ReadLine());
        Ingredients ingred = new Ingredients();
        ingred.getUserInput();
        Console.Write("No of procedures: ");
        numOfSteps = Convert.ToInt32(Console.ReadLine());
        Steps st = new Steps(); 
        st.getSteps();
        ingred.getUserOutput();
        st.getUserOutput();
        Console.WriteLine("Enter a multiplication factor to scale the recipe by: ");
        Console.WriteLine("1. Original quantities\n" +
            " 2.Double the quantities\n" +
            "3.Triple the quantities\n" +
            "4.Half the quantities");
        int multiplication = Convert.ToInt32(Console.ReadLine());
        if (multiplication == 2)
        {
            for (int i = 0; i < quantities.Count; i++)
            {
                quantities[i] = quantities[i] * 2;
            }
        }
        else if (multiplication == 3)
        {
            for (int i = 0; i < quantities.Count; i++)
            {
                quantities[i] = quantities[i] * 3;
            }
        }
        else if (multiplication == 4)
        {
            for (int i = 0; i < quantities.Count; i++)
            {
                quantities[i] = quantities[i] * 0.5;
            }
        }
        Console.WriteLine("Scaled recipe is:");

        for (int i = 0; i < ingredients.Count; i++)
        {
            Console.WriteLine("- " + quantities[i] + " " + units[i] + " " + ingredients[i]);
        }
        Console.WriteLine("Steps: ");
        for (int i = 0; i < procedure.Count; i++)
        {
            Console.WriteLine((i + 1) + ". " + steps[i]);
        }
        Console.WriteLine("Enter 'reset' to reset the quantities back to the original values or 'clear' to clear all data and enter a new recipe:");
        string reset = Console.ReadLine().ToLower();
        if (reset == "reset")
        {
            for (int i = 0; i < quantities.Count; i++)
            {
                quantities[i] = quantities[i] / multiplyBy;
            }
            Console.WriteLine("Your recipe is:");
            for (int i = 0; i < ingredients.Count; i++)
            {
                Console.WriteLine("- " + quantities[i] + " " + units[i] + " " + ingredients[i]);
            }
            Console.WriteLine("Procedure: ");
            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + procedure[i]);
            }
        }
        else if (reset == "clear")
        {
            ingredients.Clear();
            quantities.Clear();
            units.Clear();
            procedure.Clear();
            Console.WriteLine("Data invalid!!!!");
        }
        else
        {
            Console.WriteLine("404");
        }
    }
}

